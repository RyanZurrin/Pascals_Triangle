///driver program for PascalsTriangle class

#include "PascalsTriangle.h"
#include <iostream>

using namespace std;

int main() {

	PascalsTriangle test;
	test.fillPascalsArray();
	test.printPascalTriangle();

	return 0;
}